﻿using System;
using $safeprojectname$.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Contexts;
using System.Net;
using System.Data.Entity;

namespace $safeprojectname$.Controllers
{
    public class CategoriasController : Controller
    {
        private EFContext context = new EFContext();

        // GET: Categorias
        public ActionResult Index()
        {
            return View(context.Categorias.OrderBy(c => c.Nome));
        }

        public ActionResult Create()
        {
            return View();
        }
        //sobrecarga Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Categoria Categoria)
        {
            context.Categorias.Add(Categoria);
            context.SaveChanges();
            return RedirectToAction("Index");
        }        public ActionResult Edit(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Categoria Categoria = context.Categorias.Find(id);
            if (Categoria == null)
            {
                return HttpNotFound();
            }
            return View(Categoria);
        }
        //SOBRECARGA EDIT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Categoria Categoria)
        {
            if (ModelState.IsValid)
            {
                context.Entry(Categoria).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(Categoria);
        }        public ActionResult Details(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Categoria Categoria = context.Categorias.Find(id);
            if (Categoria == null)
            {
                return HttpNotFound();
            }
            return View(Categoria);
        }        public ActionResult Delete(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Categoria Categoria = context.Categorias.Find(id);
            if (Categoria == null)
            {
                return HttpNotFound();
            }
            return View(Categoria);
        }

        //SOBRECARGA DELETE
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(long id)
        {
            Categoria categoria = context.Categorias.Find(id);
            context.Categorias.Remove(categoria);
            context.SaveChanges();
            TempData["Message"] = "Categoria " + categoria.Nome.ToUpper() + "	foi	removido";
            return RedirectToAction("Index");
        }

    }
}